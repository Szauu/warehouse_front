import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.css']
})
export class TodoComponent implements OnInit {
  constructor() { }
  ngOnInit() {
  }

  todos =
    [
      {
        label: "nazwa taska",
        done: false,
        priority: 1
      },
      {
        label: "innyc taska",
        done: false,
        priority: 1
      },
      {
        label: "dasda taska",
        done: false,
        priority: 1
      },
      {
        label: "nazwa dasdasdtaska",
        done: false,
        priority: 1
      }
    ];


  addTodo(newTodoLabel) {
    var newTodo = {
      label: newTodoLabel,
      priority: 1,
      done: false
    };
    this.todos.push(newTodo);
  }

  deleteTodo(todo){
    this.todos = this.todos.filter(t=>t.label !== todo.label);
  }
}
