import { Component, OnInit } from '@angular/core';
import { MainService } from '../main.service';
import { Router } from '@angular/router';
import { WarItem } from '../models/warItems';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(public mainService: MainService, private router: Router) { }

  warItems: Array<WarItem> = new Array<WarItem>();
  flag: boolean = false;

  ngOnInit() {
    console.log("HomeComponent ngOnInit");
    this.getWarItems();
  }

  getWarItems() {
    this.warItems = [];
    this.mainService.getWarItems().subscribe(json => {
      console.log(json);
      json.map(w => {
        this.warItems.push(w);
      });
    });
  }

  updateWarItem(id: Number, warItem: WarItem) {
    this.mainService.putWarItems(id, warItem).subscribe(
      warItem => { }, (err: Error) => {
        console.log(err.message);
      },
      () => {this.getWarItems();
 
         });
  }

  getInputs() {
    if (!this.flag) {
      this.flag = true;
    } else {
      this.flag = true;
    }
  }

  actualizationClose() {
    if (this.flag) {
      this.flag = false;
    } else {
      this.flag = false; 
    }
 }

 deleteWarItem(id: Number) {
  this.mainService.deleteWarItem(id).subscribe(
    warItem => { }, (err: Error) => {
      console.log(err.message);
    },
    () => {this.getWarItems();
       });

}
creationRedirect() {
  this.router.navigate(['/create-war-item']);
  }


}

