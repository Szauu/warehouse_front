export interface WarItem {
    id?: string;
    brand: string,
    name: string,
    quantity: string,
    priceBuy: string,
    priceSell: string,
    note: string
  }
  
  