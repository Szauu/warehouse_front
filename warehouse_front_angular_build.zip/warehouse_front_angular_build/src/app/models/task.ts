export interface Task{
    id?:string,
    label: string,
    date: string,
    owner: string
}