export interface WarItemDto {
    id?: string;
    brand: string,
    name: string,
    quantity: string,
    priceBuy: string,
    priceSell: string,
    note: string
  }
  
  