import { Component, OnInit } from '@angular/core';
import { MainService } from '../main.service';
import { Router } from '@angular/router';
import { Task } from '../models/task'

@Component({
  selector: 'app-task',
  templateUrl: './task.component.html',
  styleUrls: ['./task.component.css']
})
export class TaskComponent implements OnInit {

  constructor(private mainService: MainService, private router: Router) { }
  flag: boolean = false;
  tasks: Array<Task> = new Array<Task>();
  task = {
    label: "",
    date: "",
    owner: ""
  }

  ngOnInit() {
    console.log("TaskComponent ngOnInit");
    this.getTasks();
    this.task = this.mainService.getTaskForm();
  }

  createTask() {
    let result: Task = {
      date: this.task.date,
      label: this.task.label,
      owner: this.task.owner
    };
    this.mainService.postTasks(result).subscribe(
      task => { },
    )
  }
  back() {
    this.router.navigate(["/todo"])
  }

  changeFlag() {
    if (!this.flag) {
      this.flag = true;
    } else {
      this.flag = false;
    }
  }
  getTasks() {
    this.tasks = [];
    this.mainService.getTasks().subscribe(json => {
      json.map(t => {
        this.tasks.push(t);
      })
    })
  }
  updateTask(id: Number, task: Task) {
    this.mainService.putTasks(id, task).subscribe(
      task => { }, (err: Error) => {
        console.log(err.message);
      },
      () => {
        this.getTasks();

      });
  }

  deleteTask(id: Number) {
    this.mainService.deleteTask(id).subscribe(
      task => { }, (err: Error) => {
        console.log(err.message);
      },
      () => {
        this.getTasks();

      });
  }
 }