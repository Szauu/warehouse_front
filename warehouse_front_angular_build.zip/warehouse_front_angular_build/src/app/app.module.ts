import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { WebsitesComponent } from './websites/websites.component';
import { NavigationComponent } from './navigation/navigation.component';

//import http

import { HttpClientModule } from '@angular/common/http'
import { MainService } from './main.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CreateWarItemComponent } from './create-war-item/create-war-item.component';
import { TodoComponent } from './todo/todo.component';
import { TaskComponent } from './task/task.component';
import { LeadComponent } from './lead/lead.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    WebsitesComponent,
    NavigationComponent,
    CreateWarItemComponent,
    TodoComponent,
    TaskComponent,
    LeadComponent,
    

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule

  ],
  providers: [
    MainService
  ],

  bootstrap: [
    AppComponent]
})
export class AppModule { }
