import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';

import { WebsitesComponent } from './websites/websites.component';
import { LeadComponent } from './lead/lead.component';
import { CreateWarItemComponent } from './create-war-item/create-war-item.component';
import { TodoComponent } from './todo/todo.component';
import { TaskComponent } from './task/task.component';


const routes: Routes = [

  {
    path: '',
    component: HomeComponent,
  },
  {
    path: 'todo',
    component: TaskComponent,
  },
  {
    path: 'websites',
    component: WebsitesComponent,
  },
  {
    path: 'lead',
    component: LeadComponent,
  },
{
  path: 'create-war-item',
    component: CreateWarItemComponent,
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
