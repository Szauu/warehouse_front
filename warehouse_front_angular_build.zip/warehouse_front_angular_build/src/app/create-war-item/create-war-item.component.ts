import { Component, OnInit, OnDestroy } from '@angular/core';
import { MainService } from '../main.service';
import { WarItem } from '../models/warItems';
import { Router } from '@angular/router';
import { WarItemDto } from '../models/warItemDto';

@Component({
  selector: 'app-create-war-item',
  templateUrl: './create-war-item.component.html',
  styleUrls: ['./create-war-item.component.css']
})
export class CreateWarItemComponent implements OnInit {

  constructor(private mainService: MainService, private router: Router) { }

  warItem = {
    brand: "",
    name: "",
    quantity: "",
    priceBuy: "",
    priceSell: "",
    note: ""
  }


  ngOnInit() {
    this.warItem = this.mainService.getWarItemForm();
  }

  createWarItem() {
    let result: WarItemDto = {
      brand: this.warItem.brand,
      name: this.warItem.name,
      quantity: this.warItem.quantity,
      priceBuy: this.warItem.priceBuy,
      priceSell: this.warItem.priceSell,
      note: this.warItem.note
    };
    this.mainService.postWarItems(result).subscribe(
      warItem => { },
      (err: Error) => { console.log(err.message) },
      () => {
        this.resetForm();
        this.back();
   ;
      }
    )
  }
  back() {
    this.router.navigate(['/']);
  }
  resetForm(): void {
    this.warItem ={
      brand: "",
      name: "",
      quantity: "",
      priceBuy: "",
      priceSell: "",
      note: ""
    };
  }
}