import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateWarItemComponent } from './create-war-item.component';

describe('CreateWarItemComponent', () => {
  let component: CreateWarItemComponent;
  let fixture: ComponentFixture<CreateWarItemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateWarItemComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateWarItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
