import { Injectable } from '@angular/core';
import { WarItem } from './models/warItems';
import { Observable } from 'rxjs';
import { HttpClient, HttpResponse, HttpParams } from '@angular/common/http'
import { WarItemDto } from './models/warItemDto';
import { Task } from './models/task';


@Injectable({
  providedIn: 'root'
})
export class MainService {

  warItemForm = {
    id: "",
    brand: "",
    name: "",
    quantity: "",
    priceBuy: "",
    priceSell: "",
    note: ""
  }

  taskForm = {
    id: "",
    label: "",
    date: "",
    owner: ""
  }


  constructor(private http: HttpClient) { }

  getWarItems(): Observable<Array<WarItem>> {
    return this.http.get<Array<WarItem>>('http://localhost:8081/api/waritems');
  }

  putWarItems(id: Number, WarItem: WarItem) {
    return this.http.put('http://localhost:8081/api/waritems/' + id, WarItem);
  }

  postWarItems(warItem: WarItem) {
    return this.http.post('http://localhost:8081/api/waritems/', warItem);
  }

  setWarItemForm(WarItem: any) {
    this.warItemForm = WarItem;
  }

  getWarItemForm(): any {
    return this.warItemForm;
  }

  deleteWarItem(id: Number) {
    return this.http.delete('http://localhost:8081/api/waritems/' + id);
  }


  getTasks(): Observable<Array<Task>> {
    return this.http.get<Array<Task>>('http://localhost:8081/api/tasks')
  }

  putTasks(id: Number, Task: Task) {
    return this.http.put('http://localhost:8081/api/tasks/' + id, Task)
  }
  postTasks(task: Task) {
    return this.http.post('http://localhost:8081/api/tasks/', task);
  }
  deleteTask(id: Number) {
    return this.http.delete('http://localhost:8081/api/tasks/' + id);
  }

  setTaskForm(Task: any){
    this.taskForm = Task;
  }
  getTaskForm(): any{
    return this.taskForm;
  }

}


